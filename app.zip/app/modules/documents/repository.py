from sqlalchemy.orm import Session
from sqlalchemy import select
from app.modules.documents.models import Document, DocumentChunk  # <-- ADDED DocumentChunk HERE
from app.core.enums import DocumentStatus, DocumentVisibility
from sqlalchemy import select, func


def create_document(
    db: Session, 
    user_id: int, 
    filename: str, 
    file_path: str, 
    file_size_bytes: int, 
    content_type: str,
    tenant_id: int = None,
    department_id: int = None,
    visibility: DocumentVisibility = None
) -> Document:
    db_doc = Document(
        user_id=user_id,
        filename=filename,
        file_path=file_path,
        file_size_bytes=file_size_bytes,
        content_type=content_type,
        status=DocumentStatus.PENDING,
        tenant_id=tenant_id,
        department_id=department_id,
        visibility=visibility
    )
    db.add(db_doc)
    db.commit()
    db.refresh(db_doc)
    return db_doc

def get_document_by_id(db: Session, document_id: int) -> Document | None:
    return db.get(Document, document_id)

def update_document_status(db: Session, document_id: int, status: DocumentStatus) -> None:
    db_doc = get_document_by_id(db, document_id)
    if db_doc:
        db_doc.status = status
        db.commit()

def bulk_insert_chunks(db: Session, chunks: list[DocumentChunk]) -> None:
    db.add_all(chunks)
    db.commit()

def get_documents_by_user(db: Session, user_id: int) -> list[Document]:
    stmt = select(Document).where(Document.user_id == user_id).order_by(Document.created_at.desc())
    return list(db.scalars(stmt).all())


def get_filtered_documents(db: Session, sql_filter) -> list[Document]:
    """
    Generic repository function. Takes a SQLAlchemy filter condition 
    and returns matching documents. The caller is responsible for providing the filter.
    """
    stmt = select(Document).where(sql_filter).order_by(Document.created_at.desc())
    return list(db.scalars(stmt).all())


# --- ADD THESE IMPORTS AT THE TOP OF THE FILE ---
from sqlalchemy import select, func

# --- ADD THESE FUNCTIONS AT THE BOTTOM OF THE FILE ---

def _reciprocal_rank_fusion(dense_results: list[dict], sparse_results: list[object], k: int = 60) -> list[int]:
    """Merges two ranked lists into a single list of chunk IDs using RRF math."""
    rrf_scores = {}
    
    for rank, item in enumerate(dense_results):
        chunk_id = item['chunk_id']
        rrf_scores[chunk_id] = rrf_scores.get(chunk_id, 0) + 1.0 / (k + rank + 1)
        
    for rank, chunk in enumerate(sparse_results):
        rrf_scores[chunk.id] = rrf_scores.get(chunk.id, 0) + 1.0 / (k + rank + 1)
        
    # Sort by combined score descending
    sorted_chunk_ids = sorted(rrf_scores.keys(), key=lambda x: rrf_scores[x], reverse=True)
    return sorted_chunk_ids





def hybrid_search(db: Session, user, query_text: str, query_embedding: list[float], limit: int = 10) -> list[str]:
    from app.dependencies.permissions import get_sql_document_filter, get_qdrant_filter
    from app.infrastructure.qdrant.client import get_qdrant_client
    from app.infrastructure.qdrant.collections import ensure_collection_exists # <-- ADD THIS
    
    # 1. DENSE SEARCH (Qdrant)
    qdrant = get_qdrant_client()
    ensure_collection_exists(qdrant) # <-- ADD THIS: Self-heals if collection is missing
    
    qdrant_filter = get_qdrant_filter(user)
    

# ... (rest of the function remains exactly the same)


    
    dense_hits = qdrant.query_points(
        collection_name="document_chunks",
        query=query_embedding,
        query_filter=qdrant_filter,
        limit=20,
        with_payload=True
    ).points
    
    dense_results = [{"chunk_id": hit.id, "text": hit.payload.get("text", "")} for hit in dense_hits]

    # 2. SPARSE SEARCH (Postgres Full Text Search)
    # sql_filter = get_sql_document_filter(user)
    # stmt = (
    #     select(DocumentChunk)
    #     .join(Document, DocumentChunk.document_id == Document.id)
    #     .where(sql_filter)
    #     # .match() automatically uses the GIN index we created in Postgres
    #     .where(DocumentChunk.content.match(query_text)) 
    #     .limit(20)
    # )


            # 2. SPARSE SEARCH (Postgres Full Text Search using plainto_tsquery for safe raw string parsing)
    sql_filter = get_sql_document_filter(user)
    stmt = (
            select(DocumentChunk)
            .join(Document, DocumentChunk.document_id == Document.id)
            .where(sql_filter)
            .where(DocumentChunk.content.op('@@')(func.plainto_tsquery('english', query_text)))
            .limit(20)
        )
    sparse_chunks = list(db.scalars(stmt).all())

    # 3. RECIPROCAL RANK FUSION
    fused_chunk_ids = _reciprocal_rank_fusion(dense_results, sparse_chunks)

    if not fused_chunk_ids:
        return []

    # 4. FETCH FINAL TEXTS in the exact RRF order
    final_stmt = select(DocumentChunk).where(DocumentChunk.id.in_(fused_chunk_ids))
    final_chunks = db.scalars(final_stmt).all()
    
    chunk_map = {chunk.id: chunk.content for chunk in final_chunks}
    return [chunk_map[cid] for cid in fused_chunk_ids if cid in chunk_map][:limit]
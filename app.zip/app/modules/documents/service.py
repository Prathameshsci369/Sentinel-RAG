import uuid
from pathlib import Path
from fastapi import UploadFile
from sqlalchemy.orm import Session
from app.core.settings import get_settings
from app.core.enums import DocumentVisibility
from app.modules.documents import repository
from app.modules.users.models import User
from app.modules.documents.schemas import DocumentUploadRequest, DocumentResponse

from app.dependencies.permissions import get_sql_document_filter # <-- ADD THIS

from app.ai.embeddings.generator import get_embedding_generator
from app.ai.reranker.client import get_reranker
from app.ai.llm.client import get_llm_client

async def upload_document(
    db: Session, 
    user: User, 
    file: UploadFile, 
    upload_data: DocumentUploadRequest # <-- ADD THIS
) -> repository.Document:
    settings = get_settings()
    upload_dir = Path(settings.upload_dir)
    
    upload_dir.mkdir(parents=True, exist_ok=True)

    file_ext = Path(file.filename).suffix
    unique_filename = f"{uuid.uuid4()}{file_ext}"
    file_path = upload_dir / unique_filename

    content = await file.read()
    file_size = len(content)

    with open(file_path, "wb") as f:
        f.write(content)

    # Inject tenant_id from the logged-in user, plus the new classification fields
    doc = repository.create_document(
        db=db,
        user_id=user.id,
        filename=file.filename,
        file_path=str(file_path),
        file_size_bytes=file_size,
        content_type=file.content_type or "application/octet-stream",
        tenant_id=user.tenant_id,               # <-- ADDED
        department_id=upload_data.department_id, # <-- ADDED
        visibility=upload_data.visibility        # <-- ADDED
    )
    
    return doc





# ... (keep upload_document exactly as it is)

# --- REPLACE THIS FUNCTION ---
def list_user_documents(db: Session, user: User) -> list[DocumentResponse]:
    # Ask the permission engine for the SQL filter based on who this user is
    sql_filter = get_sql_document_filter(user)
    
    # Pass the dynamic filter to the repository
    docs = repository.get_filtered_documents(db, sql_filter)
    return [DocumentResponse.model_validate(doc) for doc in docs]



def ask_question(db: Session, user: User, query: str) -> str:
    settings = get_settings()
    
    # 1. Generate Query Embedding
    embedding_gen = get_embedding_generator()
    query_embedding = embedding_gen.generate_embeddings([query])[0]
    
    # 2. Hybrid Search (Returns top 10 candidate texts)
    candidate_texts = repository.hybrid_search(
        db=db, 
        user=user, 
        query_text=query, 
        query_embedding=query_embedding, 
        limit=10
    )
    
    if not candidate_texts:
        return "I could not find any relevant information in the documents to answer this question."
    
    # 3. Rerank (Pick top 3 highly relevant chunks)
    reranker = get_reranker()
    top_contexts = reranker.rerank(query=query, documents=candidate_texts, top_k=3)
    
    # 4. Construct Prompt
    context_string = "\n\n---\n\n".join(top_contexts)
    
    system_prompt = (
        "You are an expert Enterprise Assistant. Answer the user's question based ONLY on the "
        "provided context. If the context does not contain the answer, say 'I don't have enough "
        "information in the provided documents to answer that.' Do not make things up."
    )
    user_prompt = f"CONTEXT:\n{context_string}\n\nQUESTION:\n{query}"
    
    # 5. Call Local LLM (Using the client we already built for llama.cpp)
    llm = get_llm_client()
    
    response = llm.chat.completions.create(
        model=settings.llm_model_name, 
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.3,
        max_tokens=1024
    )
    
    return response.choices[0].message.content
from fastapi import FastAPI


def register_middlewares(app: FastAPI) -> None:
    """
    Register all application middleware.
    """
    pass
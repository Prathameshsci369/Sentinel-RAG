from fastapi import FastAPI
from app.core.settings import get_settings
from app.modules.health.router import router as health_router
from app.modules.users.router import router as users_router
from app.modules.documents.router import router as documents_router
from app.modules.search.router import router as search_router # <-- ADD THIS

def register_routes(app: FastAPI) -> None:
    settings = get_settings()
    
    app.include_router(health_router)
    app.include_router(users_router, prefix=settings.api_prefix)
    app.include_router(documents_router, prefix=settings.api_prefix)
    app.include_router(search_router, prefix=settings.api_prefix) # <-- ADD THIS
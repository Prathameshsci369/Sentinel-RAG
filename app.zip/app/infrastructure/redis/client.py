import redis
from app.core.settings import get_settings

_redis_client_instance = None

def get_redis_client() -> redis.Redis:
    global _redis_client_instance
    if _redis_client_instance is None:
        settings = get_settings()
        _redis_client_instance = redis.Redis(
            host=settings.redis_host,
            port=settings.redis_port,
            db=0,
            decode_responses=True
        )
    return _redis_client_instance
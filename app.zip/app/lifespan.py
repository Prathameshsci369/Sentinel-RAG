from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.core.settings import get_settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()

    print("=" * 60)
    print(f"Starting {settings.app_name}")
    print(f"Environment : {settings.environment}")
    print("=" * 60)

    yield

    print("=" * 60)
    print("Application Shutdown")
    print("=" * 60)
# scripts/dump_schema.py
import sys
from pathlib import Path

# Add project root to path so we can import app modules
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import inspect
from app.core.settings import get_settings
from app.infrastructure.database.engine import get_engine

def dump_database_schema():
    settings = get_settings()
    engine = get_engine()
    inspector = inspect(engine)
    
    output_file = "db_schema_reference.txt"
    
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("="*60 + "\n")
        f.write("ENTERPRISE RAG PLATFORM - DATABASE SCHEMA DUMP\n")
        f.write("="*60 + "\n\n")
        
        # Get all tables in the public schema
        tables = inspector.get_table_names()
        
        for table_name in tables:
            f.write(f"TABLE: {table_name}\n")
            f.write("-" * 40 + "\n")
            
            # Get Columns
            columns = inspector.get_columns(table_name)
            for col in columns:
                nullable = "NULL" if col['nullable'] else "NOT NULL"
                default = f" [DEFAULT: {col['default']}]" if col['default'] else ""
                f.write(f"  - {col['name']}: {col['type']} {nullable}{default}\n")
            
            # Get Primary Keys
            pk = inspector.get_pk_constraint(table_name)
            if pk.get('constrained_columns'):
                f.write(f"  PK: {', '.join(pk['constrained_columns'])}\n")
                
            # Get Foreign Keys
            fks = inspector.get_foreign_keys(table_name)
            for fk in fks:
                referred_table = fk.get('referred_table')
                constrained_cols = ', '.join(fk.get('constrained_columns', []))
                referred_cols = ', '.join(fk.get('referred_columns', []))
                f.write(f"  FK: {constrained_cols} -> {referred_table}({referred_cols})\n")
                
            # Get Indexes
            indexes = inspector.get_indexes(table_name)
            for idx in indexes:
                unique = "UNIQUE " if idx['unique'] else ""
                cols = ', '.join(idx['column_names'])
                f.write(f"  INDEX: {unique}({cols})\n")
                
            f.write("\n")
            
    print(f"Success! Database schema dumped to: {output_file}")

if __name__ == "__main__":
    dump_database_schema()
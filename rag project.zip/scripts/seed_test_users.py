import sys
from pathlib import Path

# Add the project root to the path so we can import our app modules
sys.path.insert(0, str(Path(__file__).parent.parent))

import bcrypt
from sqlalchemy import text
from app.infrastructure.database.engine import engine

def seed_users():
    password = "password123"
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    users_to_insert = [
        {
            "full_name": "Engineering Manager",
            "email": "manager@corp.com",
            "password_hash": hashed_password,
            "role_id": 2,      # Manager
            "tenant_id": 1,    # Main Corp
            "department_id": 1 # Engineering
        },
        {
            "full_name": "Engineering Employee",
            "email": "employee@corp.com",
            "password_hash": hashed_password,
            "role_id": 1,      # Employee
            "tenant_id": 1,    # Main Corp
            "department_id": 1 # Engineering
        }
    ]

    with engine.connect() as conn:
        for user in users_to_insert:
            # Check if user already exists
            result = conn.execute(text("SELECT id FROM users WHERE email = :email"), {"email": user["email"]})
            if result.fetchone():
                print(f"User {user['email']} already exists. Skipping.")
                continue
            
            # Insert user
            # conn.execute(
            #     text("""
            #         INSERT INTO users (full_name, email, password_hash, role_id, tenant_id, department_id, is_active) 
            #         VALUES (:full_name, :email, :password_hash, :role_id, :tenant_id, :department_id, TRUE)
            #     """),
            #     user
            # )


                        # Insert user
            conn.execute(
                text("""
                    INSERT INTO users (full_name, email, password_hash, role_id, tenant_id, department_id, is_active, is_verified) 
                    VALUES (:full_name, :email, :password_hash, :role_id, :tenant_id, :department_id, TRUE, FALSE)
                """),
                user
            )
            print(f"Successfully created user: {user['email']} (Password: {password})")
        
        conn.commit()

if __name__ == "__main__":
    print("Seeding test users...")
    seed_users()
    print("Done!")
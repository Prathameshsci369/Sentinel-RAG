



from app.infrastructure.database.base import Base
from app.modules.users.models import User
from app.modules.documents.models import Document, DocumentChunk
from app.modules.roles.models import Role
# --- ADD THESE TWO ---
from app.modules.tenants.models import Tenant
from app.modules.departments.models import Department
from app.modules.audit.models import AuditLog

target_metadata = Base.metadata
from sqlalchemy.orm import Session, sessionmaker

from app.infrastructure.database.engine import engine

SessionFactory = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
)


def get_db():
    db: Session = SessionFactory()

    try:
        yield db

    finally:
        db.close()
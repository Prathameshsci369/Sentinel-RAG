from qdrant_client import QdrantClient
from app.infrastructure.qdrant.client import get_qdrant_client

# The standard dimension size for 'all-MiniLM-L6-v2'
# EMBEDDING_DIMENSION = 1024
# COLLECTION_NAME = "document_chunks"

# def ensure_collection_exists(client: QdrantClient) -> None:
#     """Creates the Qdrant collection if it doesn't already exist."""
#     if not client.collection_exists(COLLECTION_NAME):
#         print(f"[QDRANT] Creating collection '{COLLECTION_NAME}'...")
#         client.create_collection(
#             collection_name=COLLECTION_NAME,
#             vectors_config={
#                 "size": EMBEDDING_DIMENSION,
#                 "distance": "Cosine" # Standard for sentence-transformers
#             }
#         )
#         print(f"[QDRANT] Collection '{COLLECTION_NAME}' ready.")
#     else:
#         print(f"[QDRANT] Collection '{COLLECTION_NAME}' already exists.")






from qdrant_client import QdrantClient
from app.infrastructure.qdrant.client import get_qdrant_client

# BGE-large outputs 1024 dimensions
EMBEDDING_DIMENSION = 1024 
COLLECTION_NAME = "document_chunks"



from qdrant_client import QdrantClient
from app.infrastructure.qdrant.client import get_qdrant_client
from app.core.settings import get_settings

COLLECTION_NAME = "document_chunks"

# DYNAMIC DIMENSION MAPPING
# Add new models here when you upgrade in the future
MODEL_DIMENSIONS = {
    "all-MiniLM-L6-v2": 384,
    "bge-small-en-v1.5": 384,      # <-- Your current model
    "bge-large-en-v1.5": 1024,     # <-- Future upgrade
    "nomic-embed-text-v1.5": 768,
}
DEFAULT_DIMENSION = 384 # Fallback just in case

def get_embedding_dimension() -> int:
    settings = get_settings()
    return MODEL_DIMENSIONS.get(settings.embedding_model_name, DEFAULT_DIMENSION)

def ensure_collection_exists(client: QdrantClient) -> None:
    if not client.collection_exists(COLLECTION_NAME):
        dim = get_embedding_dimension()
        print(f"[QDRANT] Creating collection '{COLLECTION_NAME}' with {dim} dimensions for model '{get_settings().embedding_model_name}'...")
        client.create_collection(
            collection_name=COLLECTION_NAME,
            vectors_config={"size": dim, "distance": "Cosine"}
        )
        print(f"[QDRANT] Collection '{COLLECTION_NAME}' ready.")
    else:
        print(f"[QDRANT] Collection '{COLLECTION_NAME}' already exists.")


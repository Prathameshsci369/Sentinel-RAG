from qdrant_client import QdrantClient
from app.core.settings import get_settings

_qdrant_client_instance = None

def get_qdrant_client() -> QdrantClient:
    global _qdrant_client_instance
    if _qdrant_client_instance is None:
        # MUST BE url=, NOT path=
        _qdrant_client_instance = QdrantClient(url="http://localhost:6333") 
    return _qdrant_client_instance
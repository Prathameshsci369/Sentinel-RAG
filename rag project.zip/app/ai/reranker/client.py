from sentence_transformers import CrossEncoder
from app.core.settings import get_settings

class Reranker:
    def __init__(self):
        settings = get_settings()
        print(f"[RERANKER] Loading local model: {settings.reranker_model_name}...")
        # CrossEncoders are fast and highly accurate for reranking
        self.model = CrossEncoder(settings.reranker_model_name)
        print(f"[RERANKER] Model loaded successfully.")

    def rerank(self, query: str, documents: list[str], top_k: int = 3) -> list[str]:
        """
        Takes a query and a list of document texts.
        Returns only the text of the top_k most relevant documents.
        """
        if not documents:
            return []
        
        # Create pairs: [[query, doc1], [query, doc2], ...]
        pairs = [[query, doc] for doc in documents]
        
        # Predict scores (returns a numpy array of floats)
        scores = self.model.predict(pairs)
        
        # Zip docs with their scores, sort by score descending
        scored_docs = list(zip(documents, scores))
        scored_docs.sort(key=lambda x: x[1], reverse=True)
        
        # Extract and return only the text of the top K
        return [doc for doc, score in scored_docs[:top_k]]

# Singleton pattern to keep the model in RAM
_reranker_instance = None

def get_reranker() -> Reranker:
    global _reranker_instance
    if _reranker_instance is None:
        _reranker_instance = Reranker()
    return _reranker_instance
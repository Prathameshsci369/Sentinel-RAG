import json
from pathlib import Path

class PromptManager:
    def __init__(self):
        self._prompts = {}
        self._load_prompts()

    def _load_prompts(self):
        prompt_path = Path(__file__).parent / "rag_prompts.json"
        if prompt_path.exists():
            with open(prompt_path, "r") as f:
                self._prompts = json.load(f)

    def get_prompt(self, version: str = "v1_standard") -> dict:
        """Returns the system and user template for the requested version."""
        prompt_config = self._prompts.get(version, self._prompts["v1_standard"])
        return prompt_config

_prompt_manager_instance = None

def get_prompt_manager() -> PromptManager:
    global _prompt_manager_instance
    if _prompt_manager_instance is None:
        _prompt_manager_instance = PromptManager()
    return _prompt_manager_instance
from sentence_transformers import SentenceTransformer
from app.core.settings import get_settings

class EmbeddingGenerator:
    def __init__(self):
        settings = get_settings()
        print(f"[EMBEDDINGS] Loading local model: {settings.embedding_model_name}...")
        # This downloads the model from HuggingFace the first time, then caches it
        self.model = SentenceTransformer(settings.embedding_model_name)
        print(f"[EMBEDDINGS] Model loaded successfully.")

    def generate_embeddings(self, texts: list[str]) -> list[list[float]]:
        """Converts a list of text strings into a list of vector floats."""
        if not texts:
            return []
        # Returns a numpy array, we convert it to a standard Python list
        embeddings = self.model.encode(texts)
        return embeddings.tolist()

# Singleton instance so we don't load the model into memory twice
_embedding_generator_instance = None

def get_embedding_generator() -> EmbeddingGenerator:
    global _embedding_generator_instance
    if _embedding_generator_instance is None:
        _embedding_generator_instance = EmbeddingGenerator()
    return _embedding_generator_instance
from openai import OpenAI
from app.core.settings import get_settings

_llm_client_instance = None

def get_llm_client() -> OpenAI:
    global _llm_client_instance
    if _llm_client_instance is None:
        settings = get_settings()
        _llm_client_instance = OpenAI(
            base_url=settings.llm_base_url, # Points to http://localhost:8080/v1
            api_key="llama-cpp" # llama.cpp doesn't check keys, but SDK requires it
        )
    return _llm_client_instance
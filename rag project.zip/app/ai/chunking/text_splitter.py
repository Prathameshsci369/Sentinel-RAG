class RecursiveTextChunker:
    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        # Split in order of preference: structural -> semantic -> character
        self.separators = ["\n\n", "\n", ". ", " ", ""]

    def split_text(self, text: str) -> list[str]:
        if not text or not text.strip():
            return []
        
        final_chunks = []
        current_texts = [text]
        
        # Iterate through separators, splitting more granularly if chunks are too big
        for separator in self.separators:
            new_texts = []
            for t in current_texts:
                if len(t) <= self.chunk_size:
                    new_texts.append(t)
                else:
                    splits = t.split(separator)
                    # Re-attach the separator to the end of the splits (except the last)
                    for i in range(len(splits) - 1):
                        splits[i] = splits[i] + separator
                    new_texts.extend(splits)
            current_texts = new_texts

        # Merge small splits together and apply overlap logic
        merged_chunks = self._merge_chunks(current_texts)
        return [chunk.strip() for chunk in merged_chunks if chunk.strip()]

    def _merge_chunks(self, splits: list[str]) -> list[str]:
        chunks = []
        current_chunk = []
        current_length = 0

        for split in splits:
            split_len = len(split)
            
            # If a single split is larger than chunk size, force it in
            if split_len > self.chunk_size:
                if current_chunk:
                    chunks.append("".join(current_chunk))
                    current_chunk = []
                    current_length = 0
                chunks.append(split)
                continue

            # If adding this split exceeds chunk size, save current chunk and start new one
            if current_length + split_len > self.chunk_size and current_chunk:
                chunks.append("".join(current_chunk))
                # Calculate overlap from the previous chunk
                overlap_text = self._get_overlap(current_chunk, self.chunk_overlap)
                current_chunk = [overlap_text] if overlap_text else []
                current_length = len(current_chunk[0]) if current_chunk else 0

            current_chunk.append(split)
            current_length += split_len

        if current_chunk:
            chunks.append("".join(current_chunk))

        return chunks

    def _get_overlap(self, chunks: list[str], overlap_size: int) -> str:
        if not overlap_size or not chunks:
            return ""
        combined = "".join(chunks)
        if len(combined) <= overlap_size:
            return combined
        # Take the last N characters to act as context overlap
        return combined[-overlap_size:]
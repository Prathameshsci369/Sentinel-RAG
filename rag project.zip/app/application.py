from fastapi import FastAPI

from app.core.settings import get_settings
from app.lifespan import lifespan

from app.router_registry import register_routes
from app.middleware_registry import register_middlewares
from app.exception_registry import register_exception_handlers


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        debug=settings.debug,
        lifespan=lifespan,
    )

    register_middlewares(app)
    register_exception_handlers(app)
    register_routes(app)

    return app
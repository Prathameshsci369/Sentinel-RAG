import enum

class DocumentStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class UserRole(str, enum.Enum):
    ADMIN = "admin"
    MANAGER = "manager"
    EMPLOYEE = "employee"

# --- REPLACE THE OLD ONE WITH THIS ---
class DocumentVisibility(str, enum.Enum):
    GENERAL = "GENERAL"
    MANAGEMENT = "MANAGEMENT"
    CONFIDENTIAL = "CONFIDENTIAL"

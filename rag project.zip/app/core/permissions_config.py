from app.core.enums import DocumentVisibility

# PERMISSION MATRIX
# Key: Role name -> Value: List of visibility levels this role is allowed to see.
# To add a new role in the future, just add it here. The filtering logic will adapt automatically.
ROLE_VISIBILITY_MATRIX = {
    "admin": [
        DocumentVisibility.GENERAL,
        DocumentVisibility.MANAGEMENT,
        DocumentVisibility.CONFIDENTIAL
    ],
    "manager": [
        DocumentVisibility.GENERAL,
        DocumentVisibility.MANAGEMENT
    ],
    "employee": [
        DocumentVisibility.GENERAL
    ]
}

# Secure default: If a role isn't in the matrix (e.g., a new role just created), 
# they only get GENERAL access.
DEFAULT_ALLOWED_VISIBILITIES = [DocumentVisibility.GENERAL]
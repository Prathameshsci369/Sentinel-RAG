from fastapi import FastAPI
from app.middleware.request_id import RequestIDMiddleware
# inside register_middlewares(app):


def register_middlewares(app: FastAPI) -> None:
    """
    Register all application middleware.
    """
    app.add_middleware(RequestIDMiddleware)

from collections.abc import Generator

from sqlalchemy.orm import Session

from app.infrastructure.database.session import SessionFactory


def get_db() -> Generator[Session, None, None]:
    db = SessionFactory()

    try:
        yield db

    finally:
        db.close()
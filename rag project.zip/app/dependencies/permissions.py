from sqlalchemy import or_, and_
from app.modules.documents.models import Document
from app.modules.users.models import User
from app.core.permissions_config import ROLE_VISIBILITY_MATRIX, DEFAULT_ALLOWED_VISIBILITIES

# def get_allowed_visibilities(user: User) -> list[str]:
#     """Helper to get the list of allowed visibility strings for a user."""
#     role_name = user.role.name if user.role else "employee"
    
#     # Fetch from matrix, fallback to secure default
#     allowed_enums = ROLE_VISIBILITY_MATRIX.get(role_name, DEFAULT_ALLOWED_VISIBILITIES)
    
#     # Convert Enums to their string values (e.g., "GENERAL", "MANAGEMENT")
#     return [v.value for v in allowed_enums]


# def get_sql_document_filter(user: User):
#     """Generates SQLAlchemy WHERE clause for Postgres."""
#     allowed_visibilities = get_allowed_visibilities(user)
    
#     # Base rule: ALWAYS restrict by tenant first
#     base_filter = (Document.tenant_id == user.tenant_id)
    
#     # If they have access to everything, just return the tenant filter
#     if len(allowed_visibilities) == 3: 
#         return base_filter
        
#     # Otherwise, dynamically filter by whatever is in the allowed list
#     return and_(
#         base_filter, 
#         Document.visibility.in_(allowed_visibilities)
#     )


# def get_qdrant_filter(user: User):
#     """Generates Qdrant Filter object for Vector Search."""
#     from qdrant_client.models import Filter, FieldCondition, MatchAny, MatchValue
    
#     allowed_visibilities = get_allowed_visibilities(user)
    
#     # Base rule: ALWAYS restrict by tenant
#     tenant_condition = FieldCondition(key="tenant_id", match=MatchValue(value=user.tenant_id))
    
#     # If they have access to everything, just return the tenant filter
#     if len(allowed_visibilities) == 3:
#         return Filter(must=[tenant_condition])
        
#     # Otherwise, dynamically filter using MatchAny (which acts like an IN clause)
#     visibility_condition = FieldCondition(
#         key="visibility", 
#         match=MatchAny(any=allowed_visibilities)
#     )
    
#     return Filter(must=[tenant_condition, visibility_condition])



from sqlalchemy import or_, and_
from app.modules.documents.models import Document
from app.modules.users.models import User
from app.core.permissions_config import ROLE_VISIBILITY_MATRIX, DEFAULT_ALLOWED_VISIBILITIES

def get_allowed_visibilities(user: User) -> list[str]:
    role_name = user.role.name if user.role else "employee"
    allowed_enums = ROLE_VISIBILITY_MATRIX.get(role_name, DEFAULT_ALLOWED_VISIBILITIES)
    return [v.value for v in allowed_enums]

def get_sql_document_filter(user: User):
    # GUARD: If user has no tenant, return a filter that matches nothing
    if not user.tenant_id:
        return (Document.id == -1) # Impossible condition, returns empty list
        
    allowed_visibilities = get_allowed_visibilities(user)
    base_filter = (Document.tenant_id == user.tenant_id)
    if len(allowed_visibilities) == 3: return base_filter
    return and_(base_filter, Document.visibility.in_(allowed_visibilities))


def get_qdrant_filter(user: User):
    from qdrant_client.models import Filter, FieldCondition, MatchAny, MatchValue
    
    # GUARD: If user has no tenant, return a filter that matches nothing
    if not user.tenant_id:
        return Filter(must=[FieldCondition(key="tenant_id", match=MatchValue(value="IMPOSSIBLE_TENANT"))])

    allowed_visibilities = get_allowed_visibilities(user)
    tenant_condition = FieldCondition(key="tenant_id", match=MatchValue(value=user.tenant_id))
    if len(allowed_visibilities) == 3: return Filter(must=[tenant_condition])
    visibility_condition = FieldCondition(key="visibility", match=MatchAny(any=allowed_visibilities))
    return Filter(must=[tenant_condition, visibility_condition])
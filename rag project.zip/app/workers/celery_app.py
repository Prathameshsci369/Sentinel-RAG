from celery import Celery
from app.core.settings import get_settings

settings = get_settings()

celery_app = Celery(
    "enterprise_rag_worker",
    broker=f"redis://{settings.redis_host}:{settings.redis_port}/0",
    backend=f"redis://{settings.redis_host}:{settings.redis_port}/1"
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
)

# Auto-discover tasks in the future if needed
# celery_app.autodiscover_tasks(['app.workers'])

import app.modules.ingestion.service 
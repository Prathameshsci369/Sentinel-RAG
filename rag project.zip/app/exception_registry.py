from fastapi import FastAPI


def register_exception_handlers(app: FastAPI) -> None:
    """
    Register all global exception handlers.
    """
    pass
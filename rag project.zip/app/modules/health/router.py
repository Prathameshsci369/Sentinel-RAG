# from fastapi import APIRouter

# from app.core.settings import get_settings

# router = APIRouter(tags=["Health"])

# settings = get_settings()


# @router.get("/health")
# async def health_check():
#     return {
#         "status": "healthy",
#         "service": settings.app_name,
#         "version": settings.app_version,
#         "environment": settings.environment,
#     }



from fastapi import APIRouter
from app.infrastructure.database.session import SessionFactory
from app.infrastructure.redis.client import get_redis_client
from app.infrastructure.qdrant.client import get_qdrant_client
from app.core.settings import get_settings

router = APIRouter(tags=["Health"])

@router.get("/health")
async def root_health():
    return {"status": "alive"}

@router.get("/health/db")
async def check_db():
    try:
        db = SessionFactory()
        #db.execute("SELECT 1")
        from sqlalchemy import text
        db.execute(text("SELECT 1"))
        db.close()
        return {"status": "healthy", "service": "postgresql"}
    except Exception as e:
        return {"status": "unhealthy", "service": "postgresql", "error": str(e)}, 503

@router.get("/health/redis")
async def check_redis():
    try:
        client = get_redis_client()
        client.ping()
        return {"status": "healthy", "service": "redis"}
    except Exception as e:
        return {"status": "unhealthy", "service": "redis", "error": str(e)}, 503

@router.get("/health/qdrant")
async def check_qdrant():
    try:
        client = get_qdrant_client()
        #client.list_collections()
        client.get_collections()
        return {"status": "healthy", "service": "qdrant"}
    except Exception as e:
        return {"status": "unhealthy", "service": "qdrant", "error": str(e)}, 503

@router.get("/health/llm")
async def check_llm():
    try:
        # We just check if the local host/port is open, we don't waste tokens
        import socket
        settings = get_settings()
        host = settings.llm_base_url.replace("http://", "").split(":")[0]
        port = int(settings.llm_base_url.split(":")[-1].replace("/v1", ""))
        with socket.create_connection((host, port), timeout=2):
            return {"status": "healthy", "service": "llama.cpp"}
    except Exception as e:
        return {"status": "unhealthy", "service": "llama.cpp", "error": str(e)}, 503
from fastapi import APIRouter

from app.core.settings import get_settings

router = APIRouter(tags=["Health"])

settings = get_settings()


@router.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": settings.app_name,
        "version": settings.app_version,
        "environment": settings.environment,
    }
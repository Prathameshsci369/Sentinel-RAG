from app.modules.documents.service import ask_question
from app.ai.llm.client import get_llm_client
from app.core.settings import get_settings

from .schemas import EvaluationRequest  # <-- ADD THIS LINE
EVALUATOR_PROMPT = """
You are an impartial RAG evaluation judge. 
Compare the 'Generated Answer' against the 'Ground Truth'.
The Generated Answer is based ONLY on the provided context, so it might be less detailed than the Ground Truth.
Evaluate if the core facts and intent match.

Respond STRICTLY in this JSON format:
{
    "is_correct": true/false,
    "reasoning": "One sentence explaining why."
}
"""
settings = get_settings()
def run_evaluation(db, user, request: EvaluationRequest) -> dict:
    # 1. Get the RAG system's answer
    generated_answer = ask_question(db=db, user=user, query=request.question, prompt_version=request.prompt_version)
    
    # 2. Ask the LLM to evaluate
    llm = get_llm_client()
    eval_prompt = f"Ground Truth: {request.ground_truth}\n\nGenerated Answer: {generated_answer}\n\n{EVALUATOR_PROMPT}"
    
    response = llm.chat.completions.create(
        model=settings.llm_model_name,
        messages=[{"role": "user", "content": eval_prompt}],
        temperature=0.0 # Deterministic for grading
    )
    
    # 3. Parse the LLM's JSON response (safely)
    import json
    try:
        eval_result = json.loads(response.choices[0].message.content)
    except json.JSONDecodeError:
        eval_result = {"is_correct": False, "reasoning": "Failed to parse evaluator response."}
        
    return {
        "question": request.question,
        "generated_answer": generated_answer,
        "ground_truth": request.ground_truth,
        "is_correct": eval_result.get("is_correct", False),
        "evaluator_reasoning": eval_result.get("reasoning", "")
    }
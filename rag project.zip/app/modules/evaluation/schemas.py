from pydantic import BaseModel

class EvaluationRequest(BaseModel):
    question: str
    ground_truth: str
    prompt_version: str = "v1_standard" # Test different prompts!

class EvaluationResponse(BaseModel):
    question: str
    generated_answer: str
    ground_truth: str
    is_correct: bool
    evaluator_reasoning: str
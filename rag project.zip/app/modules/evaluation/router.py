from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.infrastructure.database.session import get_db
from app.dependencies.auth import get_current_user
from app.modules.users.models import User
from .schemas import EvaluationRequest, EvaluationResponse
from . import service

router = APIRouter(prefix="/evaluation", tags=["Evaluation"])

@router.post("/run", response_model=EvaluationResponse)
def evaluate_rag(
    request: EvaluationRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Runs the RAG pipeline and evaluates the generated answer against ground truth.
    """
    return service.run_evaluation(db=db, user=current_user, request=request)
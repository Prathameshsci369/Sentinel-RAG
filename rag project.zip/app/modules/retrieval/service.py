from app.ai.embeddings.generator import get_embedding_generator
from app.infrastructure.qdrant.client import get_qdrant_client
from app.infrastructure.qdrant.collections import COLLECTION_NAME
from app.modules.users.models import User # <-- ADD THIS
from app.dependencies.permissions import get_qdrant_filter # <-- ADD THIS





from app.modules.users.models import User # <-- ADD THIS
from app.dependencies.permissions import get_qdrant_filter # <-- ADD THIS

def retrieve_relevant_chunks(query: str, user: User, top_k: int = 3) -> list[dict]:
    """
    Takes a user query, embeds it, and searches Qdrant.
    Applies RBAC filter so users only find vectors they are allowed to see.
    """
    print(f"[RETRIEVAL] Searching for: '{query}'")
    
    # 1. Embed the query
    embedding_gen = get_embedding_generator()
    query_embedding = embedding_gen.generate_embeddings([query])[0]
    
    # 2. Get the dynamic Qdrant filter based on user's role
    qdrant_filter = get_qdrant_filter(user)
    
    # 3. Search Qdrant with the filter applied
    qdrant = get_qdrant_client()
    search_results = qdrant.query_points(
        collection_name=COLLECTION_NAME,
        query=query_embedding,
        query_filter=qdrant_filter, # <-- SECURITY APPLIED HERE
        limit=top_k,
        with_payload=True
    )
    
    # 4. Format results
    chunks = []
    for point in search_results.points:
        chunks.append({
            "score": point.score,
            "text": point.payload["text"],
            "chunk_index": point.payload["chunk_index"]
        })
        
    print(f"[RETRIEVAL] Found {len(chunks)} relevant chunks.")
    return chunks
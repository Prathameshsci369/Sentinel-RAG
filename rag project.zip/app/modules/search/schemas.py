from pydantic import BaseModel

class SearchRequest(BaseModel):
    query: str

class Citation(BaseModel):
    chunk_index: int
    text: str
    score: float

class SearchResponse(BaseModel):
    answer: str
    citations: list[Citation]
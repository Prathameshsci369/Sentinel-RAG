from app.ai.llm.client import get_llm_client
from app.modules.retrieval import service as retrieval_service
from app.modules.search.schemas import SearchRequest, SearchResponse, Citation
from app.core.settings import get_settings
from app.modules.users.models import User  # Ensure this is here

def ask_question(user: User, request: SearchRequest) -> SearchResponse:  # <-- MUST HAVE user: User HERE
    # Pass the user object to retrieval
    retrieved_chunks = retrieval_service.retrieve_relevant_chunks(request.query, user=user, top_k=3)
    
    if not retrieved_chunks:
        return SearchResponse(
            answer="I could not find any relevant information in the documents to answer your question.",
            citations=[]
        )

    context_text = "\n\n---\n\n".join([chunk["text"] for chunk in retrieved_chunks])
    
    system_prompt = (
        "You are an expert enterprise assistant. Answer the user's question based ONLY on the "
        "provided context. If the context does not contain the answer, say you don't know. "
        "Do not make up information. Be concise and accurate."
    )
    
    user_prompt = f"CONTEXT:\n{context_text}\n\nQUESTION:\n{request.query}"

    settings = get_settings()
    llm = get_llm_client()
    
    print(f"[RAG] Calling local LLM ({settings.llm_model_name})...")
    response = llm.chat.completions.create(
        model=settings.llm_model_name,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.2
    )
    
    answer = response.choices[0].message.content
    print(f"[RAG] LLM responded successfully.")

    citations = [
        Citation(
            chunk_index=chunk["chunk_index"],
            text=chunk["text"][:200] + "...",
            score=chunk["score"]
        )
        for chunk in retrieved_chunks
    ]

    return SearchResponse(answer=answer, citations=citations)

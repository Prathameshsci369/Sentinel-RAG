from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from app.infrastructure.database.session import get_db
from app.dependencies.auth import get_current_user
from app.modules.users.models import User
from app.modules.search.schemas import SearchRequest, SearchResponse
from app.modules.search import service

router = APIRouter(prefix="/search", tags=["Search"])

# @router.post("/ask", response_model=SearchResponse)
# def ask_question(
#     request: SearchRequest,
#     current_user: User = Depends(get_current_user)
# ):
#     """
#     Takes a query, searches the vector database, and asks the local LLM.
#     Returns the answer along with source citations.
#     """
#     return service.ask_question(current_user.id, request)


@router.post("/ask", response_model=SearchResponse)
def ask_question(
    request: SearchRequest,
    current_user: User = Depends(get_current_user) # The security guard intercepts here
):
    # Pass the whole user object down
    return service.ask_question(user=current_user, request=request)
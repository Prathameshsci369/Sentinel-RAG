import uuid
from pathlib import Path
from fastapi import UploadFile
from sqlalchemy.orm import Session
from app.core.settings import get_settings
from app.core.enums import DocumentVisibility
from app.modules.documents import repository
from app.modules.users.models import User
from app.modules.documents.schemas import DocumentUploadRequest, DocumentResponse

from app.dependencies.permissions import get_sql_document_filter # <-- ADD THIS

from app.ai.embeddings.generator import get_embedding_generator
from app.ai.reranker.client import get_reranker
from app.ai.llm.client import get_llm_client

import hashlib
from app.infrastructure.redis.client import get_redis_client

from app.ai.prompts.manager import get_prompt_manager

async def upload_document(
    db: Session, 
    user: User, 
    file: UploadFile, 
    upload_data: DocumentUploadRequest # <-- ADD THIS
) -> repository.Document:
    settings = get_settings()
    upload_dir = Path(settings.upload_dir)
    
    upload_dir.mkdir(parents=True, exist_ok=True)

    file_ext = Path(file.filename).suffix
    unique_filename = f"{uuid.uuid4()}{file_ext}"
    file_path = upload_dir / unique_filename

    content = await file.read()
    file_size = len(content)

    with open(file_path, "wb") as f:
        f.write(content)

    # Inject tenant_id from the logged-in user, plus the new classification fields
    doc = repository.create_document(
        db=db,
        user_id=user.id,
        filename=file.filename,
        file_path=str(file_path),
        file_size_bytes=file_size,
        content_type=file.content_type or "application/octet-stream",
        tenant_id=user.tenant_id,               # <-- ADDED
        department_id=upload_data.department_id, # <-- ADDED
        visibility=upload_data.visibility        # <-- ADDED
    )
    
    return doc





# ... (keep upload_document exactly as it is)

# --- REPLACE THIS FUNCTION ---
#def ask_question(db: Session, user: User, query: str) -> str:
def ask_question(db: Session, user: User, query: str, prompt_version: str = "v1_standard") -> str:
    settings = get_settings()
    redis_client = None
    
    # 1. Generate a deterministic cache key
    # Scope by tenant_id so different companies don't share cache for generic queries
    query_hash = hashlib.md5(query.encode('utf-8')).hexdigest()
    cache_key = f"llm:cache:tenant:{user.tenant_id}:query:{query_hash}"
    
    try:
        redis_client = get_redis_client()
        # 2. Check Cache (Cache Hit)
        cached_response = redis_client.get(cache_key)
        if cached_response:
            print(f"[RAG] Cache HIT for query: '{query[:50]}...'")
            return cached_response
    except Exception as e:
        # Fail-Open: If Redis is down, we just skip caching and do the full RAG pipeline
        print(f"[RAG] Redis connection failed, skipping cache. Error: {e}")

    print(f"[RAG] Cache MISS for query: '{query[:50]}...'. Executing full pipeline...")

    # =========================================================================
    # EXISTING RAG PIPELINE (Steps 3, 4, 5 from before)
    # =========================================================================
    
    # 3. Generate Query Embedding
    embedding_gen = get_embedding_generator()
    query_embedding = embedding_gen.generate_embeddings([query])[0]
    
    # 4. Hybrid Search (Returns top 10 candidate texts)
    candidate_texts = repository.hybrid_search(
        db=db, 
        user=user, 
        query_text=query, 
        query_embedding=query_embedding, 
        limit=10
    )
    
    if not candidate_texts:
        return "I could not find any relevant information in the documents to answer this question."
    
    # 5. Rerank (Pick top 3)
    reranker = get_reranker()
    top_contexts = reranker.rerank(query=query, documents=candidate_texts, top_k=3)
    
    
    # 6. Construct Prompt (Using Versioned Prompts)
    context_string = "\n\n---\n\n".join(top_contexts)
    
    prompt_manager = get_prompt_manager()
    # You could pass prompt_version as an argument to ask_question later!
    #prompt_config = prompt_manager.get_prompt(version="v1_standard") 
    prompt_config = prompt_manager.get_prompt(version=prompt_version)
    
    system_prompt = prompt_config["system"]
    user_prompt = prompt_config["user_template"].format(context=context_string, query=query)
    
    # 7. Call Local LLM
    llm = get_llm_client()
    
    response = llm.chat.completions.create(
        model=settings.llm_model_name, 
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.3,
        max_tokens=1024
    )
    
    final_answer = response.choices[0].message.content

    # =========================================================================
    # 8. Save to Cache (Cache Miss)
    # =========================================================================
    if redis_client:
        try:
            # setex sets the key with an expiration time (TTL)
            redis_client.setex(cache_key, settings.llm_cache_ttl, final_answer)
            print(f"[RAG] Saved response to Redis cache (TTL: {settings.llm_cache_ttl}s)")
        except Exception as e:
            print(f"[RAG] Failed to save to Redis cache. Error: {e}")

    return final_answer







def list_user_documents(db: Session, user: User) -> list[DocumentResponse]:
    sql_filter = get_sql_document_filter(user)
    docs = repository.get_active_filtered_documents(db, sql_filter) # CHANGED THIS LINE
    return [DocumentResponse.model_validate(doc) for doc in docs]
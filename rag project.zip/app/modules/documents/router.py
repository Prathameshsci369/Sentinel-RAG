from fastapi import APIRouter, Depends, UploadFile, File, Form, status # <-- REMOVED BackgroundTasks
from sqlalchemy.orm import Session
from app.infrastructure.database.session import get_db
from app.dependencies.auth import get_current_user
from app.modules.users.models import User
from app.modules.documents.schemas import DocumentResponse, DocumentUploadRequest
from app.modules.documents import service
from app.modules.ingestion.service import process_document_task # The celery task

router = APIRouter(prefix="/documents", tags=["Documents"])

@router.post("/upload", response_model=DocumentResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    # REMOVED background_tasks: BackgroundTasks
    department_id: int | None = Form(None),
    visibility: str = Form("general"),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    from app.core.enums import DocumentVisibility
    try:
        vis_enum = DocumentVisibility(visibility.upper())
    except ValueError:
        vis_enum = DocumentVisibility.GENERAL

    upload_data = DocumentUploadRequest(
        department_id=department_id,
        visibility=vis_enum
    )

    new_doc = await service.upload_document(db=db, user=current_user, file=file, upload_data=upload_data)
    
    # THE SWITCH: Send to Celery instead of FastAPI
    process_document_task.delay(new_doc.id)
    
    return new_doc

# ... inside router.py, update the list endpoint:

@router.get("/", response_model=list[DocumentResponse])
def list_documents(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Pass the whole user object now
    return service.list_user_documents(db, current_user)


# Add these to your imports at the top of router.py
from app.modules.documents.schemas import QuestionRequest, QuestionResponse

# Add this route inside the router class
@router.post("/ask", response_model=QuestionResponse)
def ask_question(
    request: QuestionRequest, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(get_current_user)
):
    """
    Takes a query, performs hybrid search, reranks, and asks the local LLM.
    """
    answer = service.ask_question(db=db, user=current_user, query=request.query)
    return QuestionResponse(answer=answer)
from datetime import datetime
from pydantic import BaseModel, ConfigDict
from app.core.enums import DocumentStatus, DocumentVisibility

class DocumentResponse(BaseModel):
    id: int
    user_id: int
    filename: str
    status: DocumentStatus
    tenant_id: int | None = None
    department_id: int | None = None
    visibility: DocumentVisibility | None = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

# --- ADD THIS NEW SCHEMA ---
class DocumentUploadRequest(BaseModel):
    department_id: int | None = None
    visibility: DocumentVisibility = DocumentVisibility.GENERAL


# Add these to the bottom of the file
class QuestionRequest(BaseModel):
    query: str

class QuestionResponse(BaseModel):
    answer: str
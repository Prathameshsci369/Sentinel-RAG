from fastapi import APIRouter, Depends, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.infrastructure.database.session import get_db
from app.modules.users.schemas import UserCreate, UserResponse, TokenResponse
from app.modules.users import service
from app.dependencies.auth import get_current_user # <-- ADD THIS IMPORT
from app.modules.users.models import User           # <-- ADD THIS IMPORT

router = APIRouter(prefix="/users", tags=["Users"])

@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(user_in: UserCreate, db: Session = Depends(get_db)):
    return service.register_user(db, user_in)

@router.post("/login", response_model=TokenResponse)
def login(
    form_data: OAuth2PasswordRequestForm = Depends(), 
    db: Session = Depends(get_db)
):
    return service.authenticate_user(db, email=form_data.username, password=form_data.password)

# --- ADD THIS NEW ROUTE ---
@router.get("/me", response_model=UserResponse)
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    """
    Returns the profile of the currently authenticated user.
    Requires a valid JWT token in the Authorization header.
    """
    return UserResponse.model_validate(current_user)
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from app.modules.users.schemas import UserCreate, UserResponse, TokenResponse
from app.modules.users import repository
from app.core.security import get_password_hash, verify_password, create_access_token

def register_user(db: Session, user_in: UserCreate) -> UserResponse:
    # Check if user already exists
    existing_user = repository.get_user_by_email(db, email=user_in.email)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this email already exists."
        )
    
    # Hash password and create
    hashed_password = get_password_hash(user_in.password)
    #new_user = repository.create_user(db, user_in=user_in, hashed_password=hashed_password)
    new_user = repository.create_user(db, user_data=user_in, hashed_password=hashed_password)
    
    return UserResponse.model_validate(new_user)

def authenticate_user(db: Session, email: str, password: str) -> TokenResponse:
    user = repository.get_user_by_email(db, email=email)
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive."
        )
    
    # Generate Token
    access_token = create_access_token(data={"sub": user.email})
    return TokenResponse(access_token=access_token)
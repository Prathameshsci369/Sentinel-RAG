import fitz  # PyMuPDF
import traceback
from sqlalchemy.orm import Session
from app.modules.documents.models import DocumentChunk
from app.modules.documents import repository
#from app.ai.chunking.text_splitter import TextChunker
from app.ai.chunking.text_splitter import RecursiveTextChunker
from app.core.enums import DocumentStatus
from app.ai.embeddings.generator import get_embedding_generator
from app.infrastructure.qdrant.client import get_qdrant_client
from app.infrastructure.qdrant.collections import ensure_collection_exists
from qdrant_client.models import PointStruct
from app.workers.celery_app import celery_app

from app.infrastructure.database.session import SessionFactory

# Qdrant payload field names
COLLECTION_NAME = "document_chunks"

@celery_app.task(bind=True, max_retries=3)
def process_document_task(self, document_id: int):

    print(f"\n--- [INGESTION] STARTED for doc_id: {document_id} ---")
    
    from app.infrastructure.database.session import SessionFactory
    db = SessionFactory()
    
    try:
        repository.update_document_status(db, document_id, DocumentStatus.PROCESSING)
        doc = repository.get_document_by_id(db, document_id)
        
        if not doc:
            print(f"[INGESTION] ERROR: Document {document_id} not found!")
            return

        # 1. Extract Text
        text = ""
        if doc.content_type == "application/pdf":
            text = _extract_text_from_pdf(doc.file_path)
        elif doc.content_type == "text/plain":
            with open(doc.file_path, "r", encoding="utf-8") as f:
                text = f.read()
        else:
            raise ValueError(f"Unsupported file type: {doc.content_type}")

        if not text.strip():
            raise ValueError("Extracted text is empty.")

        # 2. Chunk Text
        chunker = RecursiveTextChunker(chunk_size=1000, chunk_overlap=200)
        text_chunks = chunker.split_text(text)
        print(f"[INGESTION] Chunked into {len(text_chunks)} pieces.")

        # 3. Save Chunks to PostgreSQL
        db_chunks = [
            DocumentChunk(document_id=document_id, chunk_index=i, content=chunk)
            for i, chunk in enumerate(text_chunks)
        ]
        repository.bulk_insert_chunks(db, db_chunks)
        print(f"[INGESTION] Saved {len(db_chunks)} chunks to PostgreSQL.")

        # ---------------------------------------------------------
        # NEW: 4. Generate Embeddings
        # ---------------------------------------------------------
        print(f"[INGESTION] Generating local embeddings...")
        embedding_gen = get_embedding_generator()
        embeddings = embedding_gen.generate_embeddings(text_chunks)
        print(f"[INGESTION] Generated {len(embeddings)} embeddings.")

        # ---------------------------------------------------------
        # NEW: 5. Upload to Qdrant
        # ---------------------------------------------------------
        print(f"[INGESTION] Uploading to Qdrant...")
        qdrant = get_qdrant_client()
        ensure_collection_exists(qdrant)

        # Prepare data for Qdrant
        qdrant_points = [
            PointStruct(
                id=db_chunk.id,
                vector=embeddings[i],
                payload={
                    "document_id": document_id,
                    "chunk_index": db_chunk.chunk_index,
                    "text": db_chunk.content,
                    "tenant_id": doc.tenant_id,
                    "department_id": doc.department_id,
                    "visibility": doc.visibility.value if doc.visibility else "GENERAL"
                },
            )
            for i, db_chunk in enumerate(db_chunks)
        ]

        # Upload in batches (Qdrant handles this efficiently)
        qdrant.upsert(
            collection_name=COLLECTION_NAME,
            points=qdrant_points
        )
        print(f"[INGESTION] Successfully uploaded {len(qdrant_points)} vectors to Qdrant.")

        # 6. Mark as completed
        repository.update_document_status(db, document_id, DocumentStatus.COMPLETED)
        print(f"--- [INGESTION] FINISHED SUCCESSFULLY ---\n")

    # except Exception as e:
    #     print(f"\n!!! [INGESTION] CRASHED: {str(e)} !!!")
    #     traceback.print_exc()
    #     try:
    #         repository.update_document_status(db, document_id, DocumentStatus.FAILED)
    #     except:
    #         pass
    # finally:
    #     db.close()

    except Exception as e:
        print(f"\n!!! [INGESTION] CRASHED: {str(e)} !!!")
        traceback.print_exc()
        try:
            # Mark as failed in DB immediately
            
            db = SessionFactory()
            try:
                repository.update_document_status(db, document_id, DocumentStatus.FAILED)
            finally:
                db.close()
            
            # Tell Celery to retry in 10 seconds
            raise self.retry(exc=e, countdown=10)
        except self.MaxRetriesExceededError:
            print(f"!!! [INGESTION] Max retries exceeded for doc {document_id} !!!")

def _extract_text_from_pdf(file_path: str) -> str:
    text = ""
    try:
        with fitz.open(file_path) as doc:
            for page in doc:
                text += page.get_text()
    except Exception as e:
        raise RuntimeError(f"PDF parsing failed: {str(e)}")
    return text